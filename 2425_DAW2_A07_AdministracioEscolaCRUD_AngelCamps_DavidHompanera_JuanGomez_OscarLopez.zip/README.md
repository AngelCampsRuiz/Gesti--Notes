# Gesti--Notes
Gestio-Notes. Grupo: Àngel, Juanjo, Oscar, David
